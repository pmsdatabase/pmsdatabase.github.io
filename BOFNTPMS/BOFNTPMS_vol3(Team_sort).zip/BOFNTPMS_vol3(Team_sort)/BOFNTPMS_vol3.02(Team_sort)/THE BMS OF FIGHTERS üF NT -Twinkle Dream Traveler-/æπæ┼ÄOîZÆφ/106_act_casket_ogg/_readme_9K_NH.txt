設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(36), Hyper(46), Ex(49)
こんにちは、ion_trackerです。

今大会の9キー差分はこれで締めくくりたいと思います。 この作品で見せるとおりさまよっていましたね..

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(36), Hyper(46), Ex(49)
안녕하세요, ion_tracker입니다.

이번 대회 9키 차분은 이걸로 마무리 지으려고 합니다. 이 작품에서 보여주는 대로 헤매고 다녔네요..

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(36), Hyper(46), Ex(49)
Hello, this is ion_tracker speaking.

I'm going to wrap up the 9key Charts this time. I've been tossed as shown in this work..