設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(35), Hyper(45), EX(49)
実はこの作品に初めて触れた時は「？」 だったが終わった時は「！」になりました。
とにかく、これを50にするのは簡単ではありませんでした。 私の実力がそこまではできませんね。 orz
宣言の時点で誰にも触れなかったので、一度は3つを作りました。 満足するかはわかりませんね。
ありがとうございます。

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(35), Hyper(45), EX(49)
사실 이 작품을 처음 접했을 때는 "?" 였다가 다 끝났을 때는 "!"가 되었습니다.
아무튼, 이것을 50으로 만든다는 건 쉽지 않았습니다. 제 지력이 거기 까지는 못 가네요. orz
선언 시점에 아무도 접하지 않아 일단 세 개를 만들었습니다. 만족하실지는 모르겠네요. 
감사합니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(35), Hyper(45), EX(49)
In fact, when I first met this charts, I was like "?" When it was finished, it became "!".
Anyway, getting this to 50 wasn't easy. My skills can't get there. orz
At the time of declaration, no one touched, so I made three charts first. I wonder that will be satisfied.
thank you. 