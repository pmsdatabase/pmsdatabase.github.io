設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。
同封されたファイル（.ogg）の中で上書きするかどうかを尋ねるファイルが2つあれば正常です。

Normal(34), Hyper(43)
こんにちは、ion_trackerです。
ただ一人のインプレーヤーでしたが、突然9キーを作りたくなって突撃しました。
今年は印象深い作品で、matharhさんが絞ったHyperパターンがとても上手く作られていて9キー作業がしやすかったです。 ありがとうございます。
宣言した時点で、Anotherは他の人が占領されて任せます。
いろいろお疲れ様でした。 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.
동봉된 파일(.ogg)중 덮어쓸 것이냐고 묻는 파일이 2개 있으면 정상입니다.

Normal(34), Hyper(43)
안녕하세요, ion_tracker입니다.
그저 한명의 대회 순회자였습니다만, 갑자기 9키 패턴을 만들고 싶어져서 돌격했습니다.
올해 인상깊은 작품이었고, matharh 님이 짜준 Hyper 패턴이 워낙 잘 만들어져 있어서 9키 작업이 쉬웠습니다. 감사의 말씀 드립니다.
선언한 시점에 Another는 다른 분이 점령하셔서 맡기겠습니다.
여러 모로 잘 부탁드립니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.
If there are two files asking if you want to overwrite among the enclosed files (.ogg), it is normal.

Normal(34), Hyper(43)
Hello, this is ion_tracker speaking.
It was just one of user, but I suddenly wanted to make a 9 key chart, so I made.
It was an impressive piece of works the year, and Hyper chart written by matharh was so well made, it was easy to work with 9 keys. Thank you.
At the time of declaration, Another will take over and leave it to you.
Thank you in many ways. 