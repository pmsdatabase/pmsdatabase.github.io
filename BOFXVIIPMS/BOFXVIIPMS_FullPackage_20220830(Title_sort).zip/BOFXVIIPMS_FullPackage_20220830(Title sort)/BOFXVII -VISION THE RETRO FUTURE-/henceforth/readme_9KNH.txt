設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(28), Hyper(39)
こんにちは、ion_trackerです。
生きてみると…同じ時期に出てきた「Clue」チームの登場人物であるリーゼロッテのような感じがします。 ただ何らかの理由で目が離れた後、ただもう一度見たいだけですが、ある新しい出てくるその音と感覚、それはまた別の世界の美しさを感じたかもしれません。 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(28), Hyper(39)
안녕하세요, ion_tracker입니다.
살다보면... 같은 시기에 나온 [Clue]팀의 등장인물인 Lieselotte 같은 느낌이 듭니다. 단지 어떠한 이유로 눈이 멀어진 다음, 그저 다시 보고 싶을 뿐인데, 어느 새 나오는 그 소리와 감각, 그것은 또 다른 세계의 아름다움을 느꼈을지도 모르겠습니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(28), Hyper(393)
Hello, this is ion_tracker speaking.
In my life... I feel like Lieselotte, a character from the [Clue] team that came out around the same time. After being blinded for some reason, She just want to see you again, but the sound and sensation that came out of nowhere might have felt the beauty of another world. 