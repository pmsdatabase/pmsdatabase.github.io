設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(27), Hyper(41), Ex(47)
こんにちは、ion_trackerです。
最初は平凡な（？）パターンだと思いましたが、そんな形のスライドは想像もできませんでした。 私が使っていたプレイヤーがこのような密度のために問題が生じて慌てましたが…それでも早く解決されてよかったと思います。
とにかく、曲の爽やかな感じを楽しんでほしいです。 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(27), Hyper(41), Ex(47)
안녕하세요, ion_tracker입니다.
처음에는 평범한(?) 패턴일 줄 알았습니다만, 그런 형태의 슬라이드는 상상도 못했습니다. 제가 쓰던 구동기가 이런 밀도로 인해 이슈가 생겨서 당황했습니다만... 그래도 빨리 해결되어서 다행이라는 생각이 듭니다.
아무튼 곡의 상쾌한 느낌을 즐기신다면 좋겠습니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(27), Hyper(41), Ex(47)
Hello, this is ion_tracker speaking.
At first, I thought it was an ordinary (?) chart, but I never imagined a slide like that. I was puzzled because the BMS player I was using had an issue due to this density... But I think it's fortunate that it was resolved quickly.
Anyway, I hope you enjoy the refreshing feel of the song. 