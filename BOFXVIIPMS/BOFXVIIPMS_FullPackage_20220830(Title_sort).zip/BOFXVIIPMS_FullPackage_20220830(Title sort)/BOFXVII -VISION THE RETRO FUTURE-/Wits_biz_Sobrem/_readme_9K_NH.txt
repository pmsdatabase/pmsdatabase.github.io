設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(38), Hyper(45)
こんにちは、ion_trackerです。
今回はJazzに才能があったSobremさんの一風変わった曲です。
ところで、Normalが難しいようですが、私だけそうですね… 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(38), Hyper(45)
안녕하세요, ion_tracker입니다.
이번에는 Jazz에 재능이 있으신 Sobrem 님의 색다른 곡입니다.
그런데, Normal이 어려울 것 같은데, 저만 그런가요...

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(38), Hyper(45)
Hello, this is ion_tracker speaking.
This time, it's a different song by Sobrem, who has a talent for Jazz.
But, Normal chart seems difficult, is it just me...?