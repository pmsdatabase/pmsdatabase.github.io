設置方法：
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(26), Hyper(42)
こんにちは、ion_trackerです。
ただ一人の大会巡回者でしたが、突然9キーパターンを作りたくなって突撃しました。
ただ今、一歩を踏み出したユーザーにも面白いパターンをプレゼントしたかったです。 

いろいろお願いします。

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(26), Hyper(42)
안녕하세요, ion_tracker입니다.
그저 한명의 대회 순회자였습니다만, 갑자기 9키 패턴을 만들고 싶어져서 돌격했습니다.
단지 이제 첫걸음을 떼신 유저들에게도 재미있는 패턴을 선물하고 싶었습니다.
여러 모로 잘 부탁드립니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(26), Hyper(42)
Hello, this is ion_tracker.
I was just one BOF runner, but suddenly I wanted to make a 9-key pattern, so I charged.
I just wanted to present an interesting charts to users who are taking their first steps. 
Thank you in many ways. 