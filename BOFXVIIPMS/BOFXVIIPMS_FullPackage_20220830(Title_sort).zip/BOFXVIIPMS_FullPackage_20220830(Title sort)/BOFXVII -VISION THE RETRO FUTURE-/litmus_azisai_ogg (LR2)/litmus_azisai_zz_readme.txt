設置方法：
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(30), Hyper(38), Hyper-Upper(46)
こんにちは、ion_trackerです。
ただ一人の大会巡回者でしたが、突然9キーパターンを作りたくなって突撃しました。
今年印象深い作品で、簡単なパターンを考えて作ったのですが、HyperがHyper-Upperになる魔法が...
Hyper-Upperはジャンル名にUpperだけを付け加えました。

いろいろお願いします。

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(30), Hyper(38), Hyper-Upper(46)
안녕하세요, ion_tracker입니다.
그저 한명의 대회 순회자였습니다만, 갑자기 9키 패턴을 만들고 싶어져서 돌격했습니다.
올해 인상깊은 작품이었고, 쉬운 패턴을 생각해 만들기는 했습니다만, Hyper가 Hyper-Upper가 되는 마법이...
Hyper-Upper는 장르 이름에 Upper만 덧붙였습니다. 
여러 모로 잘 부탁드립니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(30), Hyper(38), Hyper-Upper(46)
Hello, this is ion_tracker.
I was just one BOF runner, but suddenly I wanted to make a 9-key pattern, so I charged.
It was an impressive piece of work this year, and I thought about an easy pattern to make. but Hyper Chart becoming Hyper-Upper...
Hyper-Upper just added (Upper) to #genre name.
Thank you in many ways. 