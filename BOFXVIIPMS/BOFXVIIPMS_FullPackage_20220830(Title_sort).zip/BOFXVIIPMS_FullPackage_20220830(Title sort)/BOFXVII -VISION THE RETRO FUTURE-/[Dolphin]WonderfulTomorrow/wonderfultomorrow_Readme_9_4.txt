設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Easy(12), Normal(19), Hyper(36), EX(40)
こんにちは、ion_trackerです。
意外なボーカル、意外のBGA、意外のポップをポップくんで書かないなんて意外です。
だから作って兼4つのパターンを作りましたが、簡単に出ましたね。 やはり高難度は作るのも難しいようです。
それでも良い曲です。 今9キーで楽しんでください。 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Easy(12), Normal(19), Hyper(36), EX(40)
의외의 보컬, 의외의 BGA, 의외의 팝을 팝군으로 쓰지 않다니 의외입니다.
그래서 만들 겸 4개 패턴을 만들었는데, 쉽게 나왔네요. 역시 고난도는 만드는 것도 어려운 것 같습니다.
그래도 좋은 곡입니다. 이제 9키로도 즐겨보세요.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Easy(12), Normal(19), Hyper(36), EX(40)
Hello, this is ion_tracker speaking.
It is surprising that unexpected vocals, BGA, and pop are not used as a Pop-gun.
So I made 4 charts to make it, and it came out easily. It also seems difficult to make high difficulty.
It's a good song though. Now enjoy with 9 keys. 