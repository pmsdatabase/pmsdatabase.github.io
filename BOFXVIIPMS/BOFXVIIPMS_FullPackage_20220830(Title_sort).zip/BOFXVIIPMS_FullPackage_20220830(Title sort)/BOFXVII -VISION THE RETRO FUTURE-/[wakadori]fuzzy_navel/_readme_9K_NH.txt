設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(36), Hyper(42)

こんにちは。 ion_trackerです。
今回はBOFXVIで優勝した組み合わせが持って出てきた良い曲です。 簡単に作るのは本当に難しいですね…それでも楽しんでいただきたいです。 
-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(36), Hyper(42)
안녕하세요. ion_tracker입니다.
이번에는 BOFXVI에서 우승했던 조합이 들고 나온 좋은 곡입니다. 쉽게 만들기가 정말 어렵네요... 그래도 즐겨주셨으면 하는 바람입니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(36), Hyper(42)
Hello. This is ion_tracker speaking.
This time, it's a good song with a combination that won BOFXVI. It's really hard to make easily... I hope you enjoy it though. 