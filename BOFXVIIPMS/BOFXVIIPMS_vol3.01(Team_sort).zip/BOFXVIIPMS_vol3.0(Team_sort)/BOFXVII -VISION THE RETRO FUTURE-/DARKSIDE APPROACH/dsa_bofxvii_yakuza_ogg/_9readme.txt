設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(37), Hyper(44), Ex(47), Upper(50)

こんにちは。 ion_trackerです。
Sound Onlyはフェイクです。 画面に合わせてパターンを入れるのは簡単ではありませんでした。 バケツ色が緑色であっても…
強烈なサウンドが支配するBass Kickに正打で当たれば7秒カットします。 注意してください。 
-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(37), Hyper(44), Ex(47), Upper(50)
안녕하세요. ion_tracker입니다.
Sound Only는 훼이크입니다. 그림에 맞춰 패턴 넣는게 쉽지 않았습니다. 바께쓰 색깔이 녹색이었어도...
강렬한 사운드가 지배하는 Bass Kick에 정타로 맞으면 7초 컷 납니다. 주의하세요.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(37), Hyper(44), Ex(47), Upper(50)
Hello. This is ion_tracker speaking.
Sound Only is a fake. It was not easy to put the pattern according to the BGA. Even if the color of the bucket was green...
If it hits with a straight hit to a bass kick dominated by an intense sound, it will be cutted in 7 seconds. Be careful. 