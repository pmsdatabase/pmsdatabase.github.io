設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(30), Hyper(45)
こんにちは、ion_trackerです。
この作品が今大会の1番打者一行は知りませんでした。
…ナフガンが必要になるかもしれませんね。 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(30), Hyper(45)
안녕하세요, ion_tracker입니다.
이 작품이 이번 대회의 1번타자일줄은 몰랐습니다.
...너프건이 필요할지도 모르겠군요.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(30), Hyper(45)
Hello, this is ion_tracker speaking.
I didn't know that this work would be the 1st hitter in this competition.
...I need a nerf gun, maybe....