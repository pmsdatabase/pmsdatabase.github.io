設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(27), Hyper(44)
こんにちは、ion_trackerです。
もう野球の季節が近づいてきましたね。 唐突に...
…そんな代打で出ました。

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(27), Hyper(44)
안녕하세요, ion_tracker입니다.
이제 야구의 계절이 다가왔네요. 뜬금없이...
...그렇게 대타로 나왔습니다.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(27), Hyper(44)
Hello, this is ion_tracker speaking.
Baseball season has arrived. Suddenly...
...And so came out as a substitute.