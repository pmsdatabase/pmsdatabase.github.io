設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(27), Hyper(43)
こんにちは、ion_trackerです。
いつものように断念されたパターンを跳ね上げました。 一番難しかったのは典型的なパターンではなく、難易度設定というか。 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(27), Hyper(43)
안녕하세요, ion_tracker입니다.
얼떨결에 포기한 패턴을 건져올렸습니다.
가장 어려웠던 것은 전형적인 패턴이 아니라, 난이도 설정이라고 할까요..


--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(27), Hyper(43)
Hello, this is ion_tracker speaking.
I accidentally picked up the retired charts. The most difficult thing is not the typical pattern, but the level setting. 