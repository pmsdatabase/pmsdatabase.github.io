設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Easy(17), Normal(30), Hyper(44), Another(48)
こんにちは、ion_trackerです。
これまでPMS差分企画2次まで進行され、我が町のゲームセンターが再開発で消えました。
そしてその前には電車がそこまで来るとは思えませんでしたが、今はここまで来ています。
この作品は2021年に記録した無機質な色。 そこにどんな色を付けるのでしょうか…
1989年度に出てきた韓国歌謡「雨の日の水彩画」に出てくる絵画持続に出る風景のように… 

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Easy(17), Normal(30), Hyper(44), Another(48)
안녕하세요, ion_tracker입니다.
그간 PMS차분기획 2차까지 진행되면서 우리 동네의 오락실이 재개발로 사라졌습니다.
그리고 그 전에는 전철이 거기까지 가리라고는 생각도 못했지만, 이제는 여기까지 오고 있습니다.
이 작품은 2021년에 기록한 무기질한 색. 그 곳에 어떤 색칠을 하게 될까요...
1989년도에 나온 "비오는 날의 수채화"에 나오는 도화지속에 나오는 풍경처럼...

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Easy(17), Normal(30), Hyper(44), Another(48)
Hello, this is ion_tracker speaking.
In the meantime, the game center in my neighborhood are disappeared due to redevelopment as the 2nd PMS addon planning was progressing.
And I never thought the commute train would go there before, but now it's coming.
This work is an inorganic color recorded in 2021. What color are you going to paint there?
Like the scenery in the drawing paper in the 1989 Korean song "Watercolor on a Rainy Day"... 