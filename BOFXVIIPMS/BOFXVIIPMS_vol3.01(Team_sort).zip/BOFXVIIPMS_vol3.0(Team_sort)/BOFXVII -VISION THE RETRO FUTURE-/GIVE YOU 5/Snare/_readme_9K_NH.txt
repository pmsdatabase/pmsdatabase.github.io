設置方法:
与えられた圧縮ファイルをそのフォルダに入れ、その中に入れてください。

Normal(28), Hyper(44)
こんにちは、ion_trackerです。
ドラム。 簡単だと思いましたか？ 知ってみると繊細なやつです。
特にSnareはさらにです。 エレクトロニカですが、Snareの魅力にすっかり落ちると、別れないでしょう。
今、スティック2本を握ってSnare rollを練習してみてください。 Velocityに注意しながら。  

-------------------------------

설치방법:
주어진 압축파일을 해당 폴더에 넣고 그 안에 넣어주세요.

Normal(28), Hyper(44)
안녕하세요, ion_tracker입니다.
드럼. 쉬울 줄 알았죠? 알고 보면 섬세한 녀석입니다.
특히 Snare는 더더욱이요. 비록 일렉트로니카지만 Snare의 매력에 푹 빠지면 헤어나오지 못할 겁니다.
지금. 스틱 2개를 쥐고 Snare roll을 연습해 보세요. Velocity에 주의하면서요.

--------------------------------

How to install:
Put the given compressed file in that folder and put it in there.

Normal(28), Hyper(44)
Hello, this is ion_tracker speaking.
Drum, you thought it would be easy, right? You know, he's a delicate guy.
Especially Snare. Although it's an electronica, once you fall in love with Snare's charm, you won't be able to get out of it.
Now, grab two sticks and practice the snare roll. Paying attention to Velocity. 